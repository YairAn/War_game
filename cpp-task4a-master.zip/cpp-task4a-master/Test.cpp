 #include "doctest.h"
 #include "Board.hpp"
 #define EPS 0.00001

 using namespace WarGame;


     
     

   TEST_CASE("test real numbers Operator *"){
       for (int i=0;i<100;i++) CHECK (i==i);
   }